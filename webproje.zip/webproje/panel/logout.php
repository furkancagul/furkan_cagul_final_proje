<?php
session_start();
ob_start();
session_destroy();
echo "<h2>Çıkış Yaptınız. Ana Sayfaya Yönlendiriliyorsunuz....</h2>";
header("Refresh: 2; url=../index.php");
ob_end_flush();
?>