<?php
$user = "admin";
$pass = "123456";
?>